import qisc
import yuzw